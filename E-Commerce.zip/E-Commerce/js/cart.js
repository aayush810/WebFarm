// Simple cart logic using localStorage
function addToCart(product){
  const cart = JSON.parse(localStorage.getItem('neomart_cart')||'[]');
  cart.push(product);
  localStorage.setItem('neomart_cart', JSON.stringify(cart));
  updateCartUI();
  alert(product.name + ' added to cart.');
}

function getCart(){
  return JSON.parse(localStorage.getItem('neomart_cart')||'[]');
}

function updateCartUI(){
  const cart = getCart();
  const list = document.getElementById('cartList');
  const totalEl = document.getElementById('cartTotal');
  const badge = document.getElementById('cartCount');
  if(badge) badge.textContent = cart.length;
  if(!list) return;
  list.innerHTML='';
  let total=0;
  cart.forEach((it, idx) => {
    total += it.price;
    const div = document.createElement('div');
    div.className='cart-item';
    div.innerHTML = `<div style="width:80px"><img src="${it.img}" style="width:100%;border-radius:6px"></div>
      <div style="flex:1"><strong>${it.name}</strong><div style="color:#bfc6cc">${it.price}₹</div></div>
      <div><button onclick="removeItem(${idx})" class="btn btn-ghost">Remove</button></div>`;
    list.appendChild(div);
  });
  if(totalEl) totalEl.textContent = total + '₹';
}

function removeItem(idx){
  const cart = getCart();
  cart.splice(idx,1);
  localStorage.setItem('neomart_cart', JSON.stringify(cart));
  updateCartUI();
}

function checkout(){
  alert('Checkout simulated. Total: ' + (document.getElementById('cartTotal')?.textContent || '0₹'));
}
