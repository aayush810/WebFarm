// NeoMart main interactions
document.addEventListener('DOMContentLoaded', ()=>{
  const h = document.querySelector('.hero-title');
  if(h){ h.style.opacity=0; h.style.transform='translateY(16px)'; setTimeout(()=>{ h.style.transition='all 700ms ease'; h.style.opacity=1; h.style.transform='none'; },150); }
  updateCartCount();
});

function updateCartCount(){
  const cart = JSON.parse(localStorage.getItem('neomart_cart')||'[]');
  const badge = document.getElementById('cartCount');
  if(badge) badge.textContent = cart.length;
}
